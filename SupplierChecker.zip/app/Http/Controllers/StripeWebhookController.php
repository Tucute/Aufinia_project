<?php

namespace App\Http\Controllers;

use App\Mail\sendEmail;
use App\Models\Email_test;
use App\Models\Licensekey;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Stripe\Webhook;
use Stripe\Exception\SignatureVerificationException;
use Laravel\Cashier\Events\WebhookReceived;
use Stripe\Event;

class StripeWebhookController extends Controller
{
    public function handleWebhook(Request $request) {
        $payload = $request->all();
        $stripeSigningSecret = config('services.stripe.webhook_secret');

        try {
            $payload = $request->getContent();
            $sigHeader = $request->header('Stripe-Signature');
            $event = Webhook::constructEvent($payload, $sigHeader, $stripeSigningSecret);            
            if ($event->type === 'customer.created') {

                $licenseKey = strtoupper($event['request']['idempotency_key']);
                $emailCustomer = $event['data']['object']['email'];
                $email_test = new Email_test();
                $email_test -> email = $emailCustomer;
                $email_test -> licenseKey = $licenseKey;
                $email_test->save();

                Mail::mailer('smtp')->to($emailCustomer)->send(new sendEmail($licenseKey, $emailCustomer));
            }        
            
            return response()->json(['status' => 'success']);
        } catch (SignatureVerificationException $e) {
            return response()->json(['error' => 'Webhook signature verification failed.'], 400);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while processing the webhook.'], 500);
        }
    }

    public function handle(Request $request)
    {
        $endpoint_secret = config('services.stripe.webhook_secret'); 
        // $payload = @file_get_contents('php://input');
        $payload = $request->all();
        // $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
        $sig_header = $request->server('HTTP_STRIPE_SIGNATURE');
        $event = null;

        $event = \Stripe\Webhook::constructEvent(
            $payload, $sig_header, $endpoint_secret
        );

        try {
            $event = \Stripe\Webhook::constructEvent(
              $payload, $sig_header, $endpoint_secret
            );
          } catch(\UnexpectedValueException $e) {
            http_response_code(400);
            exit();
          } catch(\Stripe\Exception\SignatureVerificationException $e) {
            http_response_code(400);
            exit();
        }

        switch ($event->type) {
            case 'payment_intent.succeeded':
              $paymentIntent = $event->data->object;
               
            default:
              echo 'Received unknown event type ' . $event->type;
        }

        http_response_code(200);
    }
    
}
