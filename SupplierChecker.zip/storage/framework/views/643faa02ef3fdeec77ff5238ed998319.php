<!DOCTYPE html>
<html>
<head>
    <title>Danh sách Khách hàng</title>
</head>
<body>
    <h1>License Key: </h1>
    <ul>

        <?php
            echo $licensekey;
        ?>
    </ul>
</body>
</html>
<?php /**PATH C:\Antu_Aufinia\Laravel\SupplierChecker\resources\views/customer_info.blade.php ENDPATH**/ ?>