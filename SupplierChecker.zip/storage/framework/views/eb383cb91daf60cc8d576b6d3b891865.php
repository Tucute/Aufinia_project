<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>
</head>
<body class="antialiased">
    <h1>Success</h1>
    <p><?php echo e($session->customer_details->name); ?></p>
    <p><?php echo e($session->customer_details->email); ?></p>
</body>
</html><?php /**PATH C:\Antu_Aufinia\Laravel\SupplierChecker\resources\views/product/checkout-success.blade.php ENDPATH**/ ?>