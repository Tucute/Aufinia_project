<!DOCTYPE html>
<html>
<head>
    <title>Webhook Data</title>
</head>
<body>
    <h1>License Key: {{ $licenseKey }}</h1>
    <h1>Email Customer: {{ $emailCustomer }}</h1>
</body>
</html>